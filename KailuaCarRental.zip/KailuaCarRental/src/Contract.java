public class Contract {

    public void printNotRentedCars(Controller controller) {
        controller.setupNCon("SELECT car_brand, car_model FROM cars WHERE car_isrented = 0");
    }

    public void printRentedCars(Controller controller) {
        controller.setupNCon("SELECT car_brand, car_model FROM cars WHERE car_isrented = 1");
    }
}
