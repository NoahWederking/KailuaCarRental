import java.sql.*;
import java.util.Scanner;

public class Car {
    // Instances
    Scanner scanner = new Scanner(System.in);
    public static final String database_url = "jdbc:mysql://localhost:3306/kailuacarrental";
    public java.sql.Connection con;

    // Methods
    public void printCars(Controller controller) {
        controller.setupNCon("SELECT car_brand, car_model FROM car JOIN model ON car.car_id = model.car_id " +
                "ORDER BY car.car_brand");
    }

    public void deleteCar(Controller controller) {
        controller.setupNCon("SELECT car_brand, car_model FROM car");
        System.out.println("Type the index of which car you want deleted: ");
        String input = scanner.nextLine();
        controller.modify("DELETE FROM car WHERE car_id LIKE" + "\'" + input + "\'");
        controller.modify("DELETE FROM model WHERE car_id LIKE" + "\'" + input + "\'");
    }

    public void updateCar(Controller controller) {
        controller.setupNCon("SELECT car_brand, car_model FROM car JOIN model ON car.car_id = model.car_id");
        System.out.println("Type the index of which car you want to update: ");
        int carId = scanner.nextInt() - 1;
        scanner.nextLine();
        String[] fields = {"brand", "model", "fueltype", "plate", "registration", "miles"};
        for (int i = 0; i < fields.length; i++) {
            System.out.println((i + 1) + ". " + fields[i]);
        }
        controller.setupNCon("SELECT car_brand, car_model, car_fueltype, car_plate, car_registration" +
                " FROM car JOIN model ON car.car_id = model.car_id WHERE car.car_id =" + "\'" + carId + "\'");
        System.out.println("Choose which part you want to change about the car: ");
        int fieldIndex = scanner.nextInt() - 1;
        scanner.nextLine();
        System.out.println("What do you want to change it to?");
        String newValue = scanner.nextLine();
        String field = fields[fieldIndex];
        if (fieldIndex != 2) {
            String sql = String.format("UPDATE car SET car_%s='%s' WHERE car_id=%d", field, newValue, carId);
            controller.modify(sql);
        } else {
           String sql = String.format("UPDATE model SET model_%s='%s' WHERE car_id=%d", field, newValue, carId);
            controller.modify(sql);
        }
    }

    public void printCarType(Controller controller) {
        System.out.println("Which brand would you like to see: ");
        String input = scanner.nextLine();

        controller.setupNCon("SELECT car_brand, car_model FROM car JOIN model ON car.car_id = model.car_id " +
                "WHERE car.car_id LIKE" + "\'" + input + "%\'");
    }

    public void addCar() {
        try {
            // String script = "INSERT INTO cars VALUES (null,);
            con = DriverManager.getConnection(database_url, "root", "Sommersko2008");
            Statement s = con.createStatement();
            // ResultSet rs = s.executeQuery(script);


        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
    }

}
