public class Main {

    MenuHandler menuHandler = new MenuHandler();

    public void run() {
        menuHandler.run();
    }

    public static void main(String[] args) {
        new Main().run();
    }
}

